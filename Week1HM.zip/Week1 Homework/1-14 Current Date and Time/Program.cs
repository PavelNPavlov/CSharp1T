﻿/*
Problem 14.* Current Date and Time

Create a console application that prints the current date and time. Find out how in Internet.
 * */

using System;


namespace CurrentDateTime
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Current date and time is: "+DateTime.Now);
        }
    }
}
