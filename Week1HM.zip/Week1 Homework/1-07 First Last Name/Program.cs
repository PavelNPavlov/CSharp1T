﻿/*
 Problem 7. Print First and Last Name

Create console application that prints your first and last name, each at a separate line.

 */
using System;


namespace MyName
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Pavel");
            Console.WriteLine("Pavlov\n");
        }
    }
}
